Meta programming is used for generic individual reports. These are parts of work
	* A restapi controller which generates each report with its url
	* Each report calls openpages rest api engine with a query defined for this report
	* Query result has openpages special json format, it's converted to json objects
	* A Processor processes json objects query result with meta mapping information for this report and generates a json report
	* If needed, a postprocessor is used to further customize a report.	 

# Meta configuration
	There are 3 meta configuration files. They are in resources/report?(1,2...) directory:
		* apiQuery.json - this file contains openpages query for this report
		* apiQueryParam.json - this is the same as apiQuery.json except it contains a where clause for individual report query
		* r?-meta.json - this file has all the mapping information between openpages query and report output.
	
	## meta-mapping file
	Almost all mapping of a report is defined by this file. Muti-level embedded objects can be used. These are mapping fields for a row:
	* 1 level json column meta fields 
		** name: the original openpages name. We put original name here for reference purpose. In implementation, it's the order(index) not the name that identifies a column.
		** newName: the new name in generated report
	* embedded json objects meta fields. These meta fields are optional, only applies columns for embeded json objects:
		** groupName: the name of this group
		** parent: define the parent of embedded objects:
			***: example - "" - for 1st level child, who parent is the row id
			***: example - "emails": 2nd level with "emails" as parent
			***: example - "emails,history": parents are history and emails(grandparent)
		** groupId: this id of embedded group, it can be "" for a group with only 1 item without a name like entities: ["e1", "e2"]
		** groupIdIdx: the index(column index number) of this group id.
		
# More customization of a report
	a postprocessor can be defined for a report processor, if further customization is needed. It adds/modifies/removes items for each result row.
		
# Reports Finished:
	* R1: aimsAudit
	* R2: aimsEntity

# host/user/password
	on server (default: /home/opuser/OP/OpenPages/bin/jcconfig.txt), put in host/user/password, for example:
	http://opservflin151.fyre.ibm.com:10108,OpenPagesAdministrator,passw0rd

# To resolve openpages setting 30k buffer size, we implemented
	* setting variable: maximumEntryCount, this variable if defined, resides in query folder (Q1, Q2)
	* if defined, for example 3, setting variables: apiQuery.json, apiQuery.json1, apiQuery.json2 and apiQueryParam.json, apiQueryParam.json1, apiQueryParam.json2 will be fetched 
	  and appended as variable for apiQuery.json and apiQueryParam.json. For compatible, first variable is without "0"