package com.ibm.openpages.ext.rest;

/*
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.HashMap;
*/

import java.io.IOException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.ibm.openpages.ext.rest.processor.PostProcessorR2;

@SpringBootTest
class JsonConverterTests {

	//@Test
	void contextLoads() {
		System.out.println("hello");
	}
	
	@Test
	void testDate() {
		Date dt;
		try {
			dt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX").parse("2021-02-01T00:00:00.000-08:00");
			System.out.println(dt);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/*
	//@Test 
	void testJavaxJson() {
		try {
			String jsonString = new String(Files.readAllBytes(Paths.get("src/test/resources/test1.json")));
			System.out.println(jsonString);
		     			
			JsonReader reader = Json.createReader(new StringReader(jsonString));
			JsonObject jsonObject = reader.readObject();
			
			Map<String, Boolean> config = new HashMap<>();
			config.put(JsonGenerator.PRETTY_PRINTING, true);			        
			JsonWriterFactory writerFactory = Json.createWriterFactory(config);
			        
			try(Writer writer = new StringWriter()) {
			    writerFactory.createWriter(writer).write(jsonObject);
			    String json = writer.toString();
			    System.out.println(json);
			}
			System.out.println("finish test1");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	*/
	
	//@Test
	void testLinkedHashMap() {
		try {
			String jsonString = new String(Files.readAllBytes(Paths.get("src/test/resources/testIbmOriginal.json")));
			JSONObject jsonObject = new JSONObject(jsonString);
			System.out.println(jsonObject.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}		
	}
	
	/*
	//@Test
	void test2() {
		testConvert("src/test/resources/test2-f.json", "src/test/resources/test2-meta.json", "Field");
	}
	
	//@Test
	void test3() {
		testConvert("src/test/resources/test3-f.json", "src/test/resources/test3-meta.json", "Field");
	}
	
	//@Test
	void testR1() {
		testConvert("src/test/resources/report1/test-r1-f.json", "src/test/resources/report1/test-r1-meta.json", "field");
	}
	*/
	
	//@Test
	void test123() {
		String s = "$;orm$;vrm$;";
		String[] a = s.replace("$", "").split(";");
		System.out.println(a.toString());
	}
	
	//@Test
	void testRestGetUser() {
		JCRestHelper restHelper = new JCRestHelper();
		restHelper.initUserPassword("OpenPagesAdministrator","passw0rd");
		String result = restHelper.get("http://opservflin161.fyre.ibm.com:10108/openpages/app/services/api/citi/aimsaudit");
	    System.out.println(result);
		
	}
	//@Test
	void testLogon() {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		
		headers.add("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36;");
		
		//MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<String, String>();
		//requestBody.add("j_username", "OpenPagesAdministrator");
		//requestBody.add("j_password", "#passw0rd");
		
		//HttpEntity<String> formEntity = new HttpEntity<String>(requestBody, headers);
		
		HttpEntity<String> formEntity = new HttpEntity<String>("j_username=OpenPagesAdministrator&j_password=passw0rd", headers);
		
		ResponseEntity<String> response = 
				   restTemplate.exchange("http://opservflin161.fyre.ibm.com:10108/openpages/j_security_check", HttpMethod.POST, formEntity, String.class);
		
		List<String> cookie = response.getHeaders().get("Set-Cookie");
		StringBuilder sb = new StringBuilder();
		for (String i: cookie) {
			System.out.println(i);
			sb.append(i.substring(0, i.indexOf(";"))).append(";");
		}
		System.out.println(sb.toString());
		
		HttpHeaders headers1 = new HttpHeaders();
	    headers1.setContentType(MediaType.APPLICATION_JSON);
	    headers1.add("Cookie", sb.toString());
	    
	    @SuppressWarnings({ "rawtypes", "unchecked" })
		HttpEntity requestEntity1 = new HttpEntity(null, headers1);
	    // First set the default cookie manager.
	    CookieHandler.setDefault(new CookieManager(null, CookiePolicy.ACCEPT_ALL));
	    
	    try {
			ResponseEntity<String> response1 = 
					   restTemplate.exchange("http://opservflin161.fyre.ibm.com:10108/openpages/app/services/api/citi/aimsaudit", HttpMethod.GET, requestEntity1, String.class);
		    System.out.println(response1.getBody());
	    }
	    catch (Exception e) {
	    	System.out.println(e);
	    }
	    
		    
	}
	
	//@Test
	/*
	void testQueryR1Processor() {
		try {
			new ProcessorR1("http://opservflin161.fyre.ibm.com:10108/grc/api/query", "OpenPagesAdministrator", "passw0rd").process();
		} catch (IOException | URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	*/
//	
	/*
	@Test
	void testQueryR1() {
		try {
			String url = "http://opservflin161.fyre.ibm.com:10108/grc/api/query";
			String body = new String(Files.readAllBytes(Paths.get("src/main/resources/report1/apiQuery.json")));
			JCRestHelper restHelper = new JCRestHelper("OpenPagesAdministrator","passw0rd");
			String result = restHelper.post(url, body);
			System.out.println(result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	*/
	
	//@Test
	void testDateVersion() {
		System.out.println(new PostProcessorR2().generateDateVersionId());
	}
	
	@SuppressWarnings("rawtypes")
	//@Test
	void testRest() {
		try {
		    // request url
		    String url = "http://opservflin161.fyre.ibm.com:10108/grc/api/security/roles";

		    // create auth credentials
		    String authStr = "OpenPagesAdministrator:passw0rd";
		    String base64Creds = Base64.getEncoder().encodeToString(authStr.getBytes());

		    // create headers
		    HttpHeaders headers = new HttpHeaders();
		    headers.add("Authorization", "Basic " + base64Creds);

		    // create request
		    @SuppressWarnings("unchecked")
			HttpEntity request = new HttpEntity(headers);

		    // make a request
		    ResponseEntity<String> response = new RestTemplate().exchange(url, HttpMethod.GET, request, String.class);

		    // get JSON response
		    String json = response.getBody();
		    System.out.println(json);
		} catch (Exception ex) {
		    ex.printStackTrace();
		}		
	}
	
	/*
	void testConvert(String inputFile, String metaFile, String fName) {
		try {
			String jsonString = new String(Files.readAllBytes(Paths.get(inputFile)));
			JSONObject jsonData = new JSONObject(jsonString);			
//			System.out.println(jsonObject.toString());

			String jsonString1 = new String(Files.readAllBytes(Paths.get(metaFile)));
			JSONObject jsonMeta = new JSONObject(jsonString1); 
			
			JSONArray result = new JCHelper().convertFlat2Recursive(jsonData.getJSONArray("rows"), jsonMeta.getJSONArray("mappings"), fName, null,new JCRestHelper("OpenPagesAdministrator","passw0rd"));
			System.out.println(result.toString());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		} catch (JCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}				
	}
	*/
}
