package com.ibm.openpages.ext.rest.processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProcessorR1 extends ProcessorAbstract{
	@Autowired
	PostProcessorR1 postProcessorR1;
	
	void init() {
		settingFolder = "Q1";		
		postProcessor = postProcessorR1;
		postProcessorR1.init();
	}
}
