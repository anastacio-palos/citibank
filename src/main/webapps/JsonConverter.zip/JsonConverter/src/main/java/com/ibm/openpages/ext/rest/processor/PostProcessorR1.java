package com.ibm.openpages.ext.rest.processor;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.ibm.openpages.ext.rest.JCRestHelper;

/**
 * 
 * postprocessor for R1 report
 * @author ali
 *
 */
@Component
public class PostProcessorR1 implements PostProcessor{
    private static Logger logger = Logger.getLogger(PostProcessorR1.class.getName());
//    private HashMap<String, String> userNames = new HashMap<>();
    private HashMap<String, String> names = new HashMap<>();

    public void init() {
    	//userNames.clear();
    	names.clear();
    }
    
	public void process(JSONObject o, JCRestHelper restHelper, String host) {
//		logger.info("post processing R1");
		
//		String userUrl = "[host]/grc/api/security/users/".replace("[host]",host);
		String nameUrl = "[host]/grc/api/contents/".replace("[host]",host);
		
		JSONArray auditUserList = new JSONArray();
		
		//auditExecutive empty
		o.put("auditExecutive", "");
		
		//auditOwner
		String userId = null;
		String userFull = null;
		if (o.has("auditOwner")) {
			userId = o.getString("auditOwner");
			//userFull = getUserNameWitCache(userId, restHelper, userUrl)  +" ("+userId+")";
			//o.put("auditOwner", userFull);
			auditUserList.put(createUserType(userId , "Audit Owner"));
		}
		
		//auditController
		if (o.has("auditController")) {
			userId = o.getString("auditController");
			//userFull = getUserNameWitCache(userId, restHelper, userUrl) +" ("+userId+")";
			//o.put("auditController", userFull);
			auditUserList.put(createUserType(userId , "Audit Controller"));
		}
		
		//leadAuditor
		// todo:missing
		if (o.has("leadAuditor")) {
			userId = o.getString("leadAuditor");
			//userFull = getUserNameWitCache(userId, restHelper, userUrl) +" ("+userId+")";
			//o.put("leadAuditor", userFull);
			auditUserList.put(createUserType(userId , "Lead Auditor"));
		}
		
		//additionalLeadAuditors can be multiple
		String additionalLeadAuditorsString = "";
		if (o.has("additionalLeadAuditors")) {			
			String additionalLeadAuditors = o.getString("additionalLeadAuditors");
			
			// format: 	$;orm$;vrm$;
			String[] ids = additionalLeadAuditors.replace("$", "").split(";");
			for (String id:ids) {
				if (id.length()==0) {
					continue;
				}
				//userFull = getUserNameWitCache(userId, restHelper, userUrl) +" ("+id+")";
				auditUserList.put(createUserType(id , "Additional Lead Auditor"));
				if (additionalLeadAuditorsString.length() >0) {
					additionalLeadAuditorsString += "|";				
				}
				//additionalLeadAuditorsString += userFull;
				additionalLeadAuditorsString += id;
			}
			o.put("additionalLeadAuditors", additionalLeadAuditorsString);
		}
		
		// audit360SolutionsUsed add solutionUsed: true for each item
		if (o.has("audit360SolutionsUsed")) {
			JSONArray list = o.getJSONArray("audit360SolutionsUsed");
			for (int i = 0; i < list.length(); i++){
				JSONObject r = list.getJSONObject(i);
				r.put("solutionUsed", "Yes");
			}
		}
		
		o.put("auditUserList", auditUserList);
		
		//top entity names
		/*
		if (o.has("entities")) {
			JSONArray entitieIds = o.getJSONArray("entities");
			o.put("entities", getNamesWithCache(entitieIds, restHelper, nameUrl));
			
		}
		*/
		if (o.has("auditAmrList")) {
			JSONArray amrs = o.getJSONArray("auditAmrList");
			for (int i = 0; i < amrs.length(); i++){
				JSONObject amr = amrs.getJSONObject(i);
				if (amr.has("amrEntities")) {
					JSONArray entitieIds = amr.getJSONArray("amrEntities");
					amr.put("entities", getNamesWithCache(entitieIds, restHelper, nameUrl));
					amr.remove("amrEntities");
					
				}
			}
		}
	}
	
	private JSONArray getNamesWithCache(JSONArray ids, JCRestHelper restHelper, String nameUrl) {
		JSONArray nameArray = new JSONArray();
		for (int i = 0; i < ids.length(); i++){
			String id = ids.get(i).toString();
			if (names.containsKey(id)) {
				nameArray.put(names.get(id));
			}else {
				String name = this.getName(id, restHelper, nameUrl);
				nameArray.put(name);
			}
		}
		return nameArray;		
	}

	/*
    // don't get user everytime, cache it
    private String getUserNameWitCache(String userId, JCRestHelper restHelper, String userUrl) {
		String userName = null;
		if (userNames.containsKey(userId)) {
			userName = userNames.get(userId);
		}
		else {
			userName = getUserName(userId, restHelper, userUrl);
			userNames.put(userId, userName);
		}
    	return userName;
    }
    */
	
	private JSONObject createUserType(String userId, String typeString) {
		JSONObject u = new JSONObject();
		u.put("soeId", userId);
		u.put("aimsMappedRole", typeString);
		return u;
		
	}
	
	// result: Czajka, Anna (AC68050)
	public String getUserName(String userId, JCRestHelper restHelper, String userUrl) { 
		try {
			String url = userUrl+userId;
			String jsonString = restHelper.get(url);
			JSONObject jsonObj = new JSONObject(jsonString);
			
			String retString = jsonObj.getString("lastName") +", "+jsonObj.getString("firstName");
			return retString;
		}catch (Exception e){ //sometimes, we have wrong user name
			logger.log(Level.SEVERE, "exception getUserName, invalid user id:" + userId + ", " + e.getMessage());
			return "";
		}
	}
	
	public String getName(String id, JCRestHelper restHelper, String userUrl) { 
		try {
			String url = userUrl+id;
			String jsonString = restHelper.get(url);
			JSONObject jsonObj = new JSONObject(jsonString);
			JSONArray data = jsonObj.getJSONObject("fields").getJSONArray("field");
			
			for (int i = 0; i < data.length(); i++){
				String name = data.getJSONObject(i).getString("name").toString();
				if ("name".equals(name.toLowerCase())) {
					String n = data.getJSONObject(i).getString("value").toString();
					int idx = n.indexOf(".txt");
					if (idx >=0 ) {
						n = n.substring(0,idx);
					}
					return n;
				}
			}
		}catch (Exception e){ //sometimes, we have wrong user name
			logger.log(Level.SEVERE, "exception getName, invalid id:" + id + ", " + e.getMessage());
		}
		return "";
	}

}
