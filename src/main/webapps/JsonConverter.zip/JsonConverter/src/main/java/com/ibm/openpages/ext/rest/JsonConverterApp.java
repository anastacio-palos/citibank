package com.ibm.openpages.ext.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonConverterApp {

	public static void main(String[] args) {
		SpringApplication.run(JsonConverterApp.class, args);
	}

}
