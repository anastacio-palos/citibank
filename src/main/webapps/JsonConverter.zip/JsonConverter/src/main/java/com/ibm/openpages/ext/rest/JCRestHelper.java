package com.ibm.openpages.ext.rest;

import java.util.Base64;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class JCRestHelper {
	
	HttpHeaders headers = null;
	@SuppressWarnings("rawtypes")
	HttpEntity request = null;
	RestTemplate restTemplate = null;
	
	//public RestTemplate createRestTemplate (String hostName, int port, String protocol, String userName, String password) {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JCRestHelper initUserPassword(String userName, String password) {
	    //String authStr = "OpenPagesAdministrator:passw0rd";
	    String authStr = userName+":"+password;
	    String base64Creds = Base64.getEncoder().encodeToString(authStr.getBytes());
	    
	    // create headers
	    headers = new HttpHeaders();
	    headers.add("Authorization", "Basic " + base64Creds);
	    
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    
	    // create request
		request = new HttpEntity(headers);
		
		// create rest template
		restTemplate = new RestTemplate();
		
		return this;
	}
	
	public String get(String url) {
	    // make a request with encoding disabled
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).build(true);
	    
		ResponseEntity<String> response = restTemplate.exchange(uriComponents.toUri(), HttpMethod.GET, request, String.class);

	    // get JSON response
	    String json = response.getBody();
		return json;
	}
	
	public String post(String url, String body) {
	    HttpEntity<String> request = new HttpEntity<String>(body, headers);	   
	    
	    ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);		
	    
	    String json = response.getBody();
		return json;
	}
}
