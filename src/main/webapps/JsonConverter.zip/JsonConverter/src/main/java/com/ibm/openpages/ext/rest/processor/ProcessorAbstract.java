package com.ibm.openpages.ext.rest.processor;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.ibm.openpages.ext.rest.JCException;
import com.ibm.openpages.ext.rest.JCHelper;
import com.ibm.openpages.ext.rest.JCRestHelper;

public abstract class ProcessorAbstract{
    private static Logger logger = Logger.getLogger(ProcessorAbstract.class.getName());
    
    public static final String SETTING_SEPARATOR = "%2F";
    public static final String SETTING_QUERY_FILE = "apiQuery.json";
    public static final String SETTING_QUERY_PARAM_FILE = "apiQueryParam.json";
    public static final String SETTING_META_FILE = "meta-mapping.json";
    public static final String SETTING_MAX_COUNT = "maximumEntryCount";

    
    String settingFolder = null;
    
    @Autowired JCRestHelper restHelper;
    
	String queryFile = null;
	String queryParamFile = null;
		
	String metaFile = null;
	String restApiSettingBaseUrl = null;	
	String restApiQueryString = null;	
	int maximumEntryCount = 1;
	
	PostProcessor postProcessor = null;	
	
	abstract void init();
	
	String getMaximumEntryCountUrl() {
		return restApiSettingBaseUrl + settingFolder + SETTING_SEPARATOR + SETTING_MAX_COUNT;		
	}
	String getQueryFileUrl() {
		return restApiSettingBaseUrl + settingFolder + SETTING_SEPARATOR + SETTING_QUERY_FILE;
	}
	String getQueryParamFileUrl() {
		return restApiSettingBaseUrl + settingFolder + SETTING_SEPARATOR + SETTING_QUERY_PARAM_FILE;
	}
	String getMetoFileUrl() {
		return restApiSettingBaseUrl + settingFolder + SETTING_SEPARATOR + SETTING_META_FILE;
		
	}
	public String process(String restApiUrl, String restApiUser, String restApiPassword, String restApiSettingBaseUrl, String host) 
			throws IOException, URISyntaxException, JCException {
		
		this.restApiSettingBaseUrl = restApiSettingBaseUrl;		
		init();
		
		/*
		ClassPathResource classPathResource = new ClassPathResource(queryFile);
		byte[] binaryData = FileCopyUtils.copyToByteArray(classPathResource.getInputStream());		
		restApiQueryString = new String(binaryData, StandardCharsets.UTF_8);
		*/
		
		restHelper.initUserPassword(restApiUser, restApiPassword);
		
		restApiQueryString = getSettingVar(getQueryFileUrl());
		maximumEntryCount =  getMaximumEntryCount();

		//multiple string to over 30k limit like:  apiQuery.json, apiQuery.json1, apiQuery.json2, ...
		if (maximumEntryCount>1) {
			for (int i=1;i<maximumEntryCount;i++) {
				try {
					restApiQueryString += getSettingVar(getQueryFileUrl()+i).trim();				
				}catch (Exception e) {
					logger.warning("exception getting more getQueryFileUrl for: "+i+":"+e.getMessage());
				}
			}
		}
		
		return doProcess(restApiUrl, restApiUser, restApiPassword, host, null);		
	}
	
	public String processWithId(String restApiUrl, String restApiUser, String restApiPassword, String id, String restApiSettingBaseUrl, String host) 
			throws IOException, URISyntaxException, JCException {		
		
		this.restApiSettingBaseUrl = restApiSettingBaseUrl;
		init();		
		//this.queryId = id;

		/*
		ClassPathResource classPathResource = new ClassPathResource(queryParamFile);
		byte[] binaryData = FileCopyUtils.copyToByteArray(classPathResource.getInputStream());
		restApiQueryString = new String(binaryData, StandardCharsets.UTF_8);
		*/
		
		restHelper.initUserPassword(restApiUser, restApiPassword);
		
		restApiQueryString = getSettingVar(getQueryParamFileUrl());
		
		maximumEntryCount =  getMaximumEntryCount();
		
		restApiQueryString = restApiQueryString.replace("?", id);
		if (maximumEntryCount>1) {
			for (int i=1;i<maximumEntryCount;i++) {
				try {
					restApiQueryString += getSettingVar(getQueryParamFileUrl()+i).trim();				
				}catch (Exception e) {
					logger.warning("exception getting more queryStringWithParam for: "+i+":"+e.getMessage());
				}
			}
		}

		return doProcess(restApiUrl, restApiUser, restApiPassword, host, id);
	}

	private int getMaximumEntryCount() {
		try {
			return  getSettingVarInt(getMaximumEntryCountUrl());
		}catch (Exception e) {
			logger.info("maximumEntryCount not exist");
			return 1;
		}
		
	}
	private String getSettingVar(String url) {
		JSONObject jsonData = new JSONObject(restHelper.get(url));
		return jsonData.getString("value");
	}
	private Integer getSettingVarInt(String url) {
		JSONObject jsonData = new JSONObject(restHelper.get(url));
		return jsonData.getInt("value");
	}
	
	public String doProcess(String restApiUrl, String restApiUser, String restApiPassword, String host, String queryId) throws URISyntaxException, JCException {
		
		try {
			// get json from openpage rest api 
			String jsonString = restHelper.post(restApiUrl, restApiQueryString);
			
			// processing
			JSONObject jsonData = new JSONObject(jsonString);

			/*
			ClassPathResource classPathResource = new ClassPathResource(getMetoFile());
			byte[] binaryData = FileCopyUtils.copyToByteArray(classPathResource.getInputStream());
			String jsonString1 = new String(binaryData, StandardCharsets.UTF_8);
			*/
			
			String jsonString1 = getSettingVar(getMetoFileUrl());
			if (maximumEntryCount>1) {
				for (int i=1;i<maximumEntryCount;i++) {
					try {
						jsonString1 += getSettingVar(getMetoFileUrl()+i).trim();				
					}catch (Exception e) {
						logger.warning("exception getting more queryMetaFileUrl for: "+i+":"+e.getMessage());
					}
				}
			}
			
			
			JSONObject jsonMeta = new JSONObject(jsonString1); 
			
			JSONArray result = new JCHelper().convertFlat2Recursive(jsonData.getJSONArray("rows"), jsonMeta.getJSONArray("mappings"), "field", 
					postProcessor, restHelper.initUserPassword(restApiUser,restApiPassword), host);
			String ret;
			if (queryId != null) {
				// is there a multiple instances with same id?
				if (result.length() >= 1) {
					ret = result.getJSONObject(0).toString();
				}
				else {
					ret = "{}";
				}
			}else {
				ret = result.toString();
			}
			
			//System.out.println(ret);
			return ret;
		
		} catch (JSONException|JCException e) {
			logger.log(Level.SEVERE, "error process report:"+ e.getMessage());
			throw e;
		} 
	}

	public String getQueryParamFile() {
		return queryParamFile;
	}

	public void setQueryParamFile(String queryParamFile) {
		this.queryParamFile = queryParamFile;
	}
	
	
}
