package com.ibm.openpages.ext.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.openpages.ext.rest.BaseExtController;

@SuppressWarnings("unused")
@RestController
@RequestMapping("extapi")
public class JCExtController extends BaseExtController {
	
	@GetMapping("/greeting1")
	public String greeting() {
		return "hello from JCExtController";
	}
}
