package com.ibm.openpages.ext.rest.processor;

import org.json.JSONObject;

import com.ibm.openpages.ext.rest.JCRestHelper;

public interface PostProcessor {
	public void process(JSONObject o, JCRestHelper restHelper, String host);
}
