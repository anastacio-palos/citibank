package com.ibm.openpages.ext.rest;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/* sdk
import com.ibm.openpages.api.configuration.IConfigProperties;
import com.ibm.openpages.api.service.IServiceFactory;
import com.ibm.openpages.api.service.ServiceFactory;
*/

import com.ibm.openpages.ext.rest.processor.ProcessorR1;
import com.ibm.openpages.ext.rest.processor.ProcessorR2;

@RestController
@RequestMapping("services/api/citi")
public class JCRestController extends BaseExtController
{
    private static Logger logger = Logger.getLogger(JCRestController.class.getName());
    
	private String restApiUrl="[host]/grc/api/query";
	private String restApiSettingBaseUrl="[host]/grc/api/configuration/settings/%2FOpenPages%2FCustom%20Deliverables%2FInterfaces%2FAudit360%2F";
    
	
    //local run
	/*
	private String restApiUser="OpenPagesAdministrator";
	private String restApiPassword="passw0rd";
	private String host="http://opservflin151.fyre.ibm.com:10108";
	*/
	private String restApiUser=null;
	private String restApiPassword=null;
	private String host=null;
	
	//sdk run
    /*
    
	@GetMapping("/sdktest")
	public String sdktest() {
		logger.info("sdktest");
		
		IServiceFactory	i = ServiceFactory.getServiceFactory(request);
		IConfigProperties p = i.createConfigurationService().getConfigProperties();
		
		String host = p.getProperty("/OpenPages/Custom Deliverables/Interfaces/Audit360/Shared/host");
		String user = p.getProperty("/OpenPages/Custom Deliverables/Interfaces/Audit360/Shared/restUser");		
		String password = p.getProperty("/OpenPages/Custom Deliverables/Interfaces/Audit360/Shared/restPassword");
		return user+":"+password+":"+host;
	}	
	//*/
	@GetMapping("/hosttest")
	public String hosttest() {
		return restApiUser+":"+restApiPassword+":"+host;
	}
	@PostConstruct
	public void postConstruct() throws IOException {
		String f = System.getenv("JSON_CONVERTER_ENV");
		if (f == null || f.trim().length() == 0) {
			f = "/home/opuser/OP/OpenPages/bin/jcconfig.txt";
		}

		String buf;
		buf = new String(Files.readAllBytes(Paths.get(f)));
		String[] env = buf.split(",");
		host = env[0];
		restApiUser = env[1];
		restApiPassword = env[2];
		host = host.replaceAll("[\\n\\t ]", "");
		restApiUser = restApiUser.replaceAll("[\\n\\t ]", "");
		restApiPassword = restApiPassword.replaceAll("[\\n\\t ]", "");
	}
	
	private void init() {
		
		logger.info("init");
	    
		//sdk run
	    /*
		IServiceFactory	i = ServiceFactory.getServiceFactory(request);
		IConfigProperties p = i.createConfigurationService().getConfigProperties();
		restApiUser = p.getProperty("/OpenPages/Custom Deliverables/Interfaces/Audit360/Shared/restUser");
		restApiPassword = p.getProperty("/OpenPages/Custom Deliverables/Interfaces/Audit360/Shared/restPassword");
		host = p.getProperty("/OpenPages/Custom Deliverables/Interfaces/Audit360/Shared/host");
		*/
		
		restApiSettingBaseUrl = restApiSettingBaseUrl.replace("[host]", host);
		restApiUrl = restApiUrl.replace("[host]", host);
	}
		
	@GetMapping("/exceptiontest")
	public String exceptionTest() {
		try {
			test1();
			return "good";
		} catch (Exception e) {			
			return "{ \"exception\": \""+toStack(e)+"\"}";
		}
	}
	
	private void test1() throws JCException {
		throw new JCException("jcException");
	}	
	
	@Autowired
	HttpServletRequest request;
	
	@Autowired
	private ProcessorR1 processorR1;
	
	@Autowired
	private ProcessorR2 processorR2;
	
	@GetMapping("/greeting")
	public String greeting() {
		return "hello from JsonConverter";
	}
	
	// R1
	@GetMapping("/aimsaudit")
	public String aimsAudit() {
		logger.info("aimsaudit called");
		try {
			init();
			
			return processorR1.process(restApiUrl, restApiUser, restApiPassword, restApiSettingBaseUrl, host);
		} catch (Exception e) {			
			return "{ \"exception\": \""+toStack(e)+"\"}";
		}
	}
	
	@GetMapping("/aimsauditwithparam/{id}")
	public String aimsAuditWithParsam(@PathVariable("id") String id) {
		logger.info("aimsAuditWithParsam called");
		try {
			init();

			return processorR1.processWithId(restApiUrl, restApiUser, restApiPassword, id, restApiSettingBaseUrl, host);
		} catch (Exception e) {			
			return "{ \"exception\": \""+toStack(e)+"\"}";
		}
	}

	// R2
	@GetMapping("/aimsentity")
	public String aimsEntity() {
		logger.info("aimsEntity called");
		try {
			init();
			
			return processorR2.process(restApiUrl, restApiUser, restApiPassword, restApiSettingBaseUrl, host);
		} catch (Exception e) {			
			return "{ \"exception\": \""+toStack(e)+"\"}";
		}
	}
	
	@GetMapping("/aimsentitywithparam/{id}")
	public String aimsEntityWithParsam(@PathVariable("id") String id) {
		logger.info("aimsEntityWithParsam called");
		try {
			init();
			
			return processorR2.processWithId(restApiUrl, restApiUser, restApiPassword, id, restApiSettingBaseUrl, host);
		} catch (Exception e) {			
			return "{ \"exception\": \""+toStack(e)+"\"}";
		}
	}
	
	public static String toStack(Exception e) {
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        e.printStackTrace(printWriter);
        String exceptionString = stringWriter.toString();
        return exceptionString;
  }
}
