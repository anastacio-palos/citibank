package com.ibm.openpages.ext.rest.processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProcessorR13 extends ProcessorAbstract{
	@Autowired
	PostProcessorR2 postProcessorR2;
	
	void init() {
		settingFolder = "Q13";
	}
}
