package com.ibm.openpages.ext.rest;

public class JCException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1523232976523185766L;

	public JCException() {
		super();
	}
	public JCException(String msg) {
		super(msg);
	}
}
