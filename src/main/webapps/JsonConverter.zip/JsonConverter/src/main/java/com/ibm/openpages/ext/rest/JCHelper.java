package com.ibm.openpages.ext.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.ibm.openpages.ext.rest.processor.PostProcessor;

/**
 * 
 * helper class for flat->recursive json conversion 
 * assumption: flatObjects order by rowId
 * 
 * @author AndyLi
 *
 */
@Component
public class JCHelper {
    private static Logger logger = Logger.getLogger(JCHelper.class.getName());
	
	public JSONArray convertFlat2Recursive(JSONArray flatObjects, JSONArray metas, String fName, PostProcessor postProcessor, JCRestHelper restHelper, String host) 
			throws JCException {
		logger.info("start converting");
		
		JSONArray results = new JSONArray();
		JSONObject lastObject = null;
		
		for (int i = 0; i < flatObjects.length(); i++){
			// rows is as: { "fields":{"Field":[...
			JSONArray rows = flatObjects.getJSONObject(i).getJSONObject("fields").getJSONArray(fName);
			JSONObject n = converAFlat(rows, metas, lastObject);
			if (n!=lastObject) {
				if (null!=lastObject) {
					if (postProcessor != null) {
						postProcessor.process(lastObject, restHelper, host);
					}
					results.put(lastObject);
				}
				lastObject = n;
			}
		}
		if (null!=lastObject) {
			if (postProcessor != null) {
				postProcessor.process(lastObject, restHelper, host);
			}
			results.put(lastObject);
		}
		return results;
	}
	
	/**
	 * for openpages restapi, a json property is in its special generic way as an array:
        	[{
            	"dataType": "STRING_TYPE",
             	"id": "1",
                 "name": "firstName",
                 "hasChanged": false,
                 "value": "Michael"
            },
        	{
            	"dataType": "ENUM_TYPE",
             	"id": "3",
                 "name": "OPSS-Aud:Status",
                 "hasChanged": false,
                 "enumValue": {
                 	"id": "4",
                    "name": "Not Started",
                    "localizedLabel": "Not Started",
                    "index": 1,
                    "hidden": false
                 }
             },		
             ...
	 * 
	 * @param row
	 * @param meta
	 * @param lastObject
	 * @return
	 * @throws JCException 
	 */
	public JSONObject converAFlat(JSONArray inputRow, JSONArray metas, JSONObject lastOutputObject) throws JCException {
		// if it's not new object, we reuse lastObject, 1st element is always assumed to be id. 
		JSONObject retObject = lastOutputObject;
		List<String> processedGroups = new ArrayList<String>();

		// process flat row by row
		for (int i = 0; i < inputRow.length(); i++){
			JSONObject meta = metas.getJSONObject(i);

			JSONObject ele = inputRow.getJSONObject(i);
			
			String name = meta.getString("newName");
			Object value = getValue(ele);
			
			// check if it's a new obj, assume first column is always row id
			if (i==0 && (lastOutputObject == null || !value.equals(lastOutputObject.getString(name)))) {
				retObject = new JSONObject();
			}
			
			// no parent/groupName
			if (!meta.has("parent")) {
				// only add value if not null and JSONObject ignores null anyway
				if (value != null) {
					retObject.put(name, value);
				}
				continue;
			}
			
			// group members are processed together
			String groupName = meta.getString("groupName");
			String parentGroupName = meta.getString("parent")+"-"+groupName;
			
			if (processedGroups.contains(parentGroupName)) {
				continue;
			}
			
			processGroup(groupName, i, inputRow, metas, retObject);			
			processedGroups.add(parentGroupName);			
		}
		return retObject;
	}
	
	private Object getValue(JSONObject o) {
		if (o.has("enumValue")) {
            JSONObject jsonObject1 =  ((JSONObject)o.get("enumValue"));
            if (jsonObject1.has("localizedLabel")) {
	            return jsonObject1.get("localizedLabel");
            }
            else {
	            return jsonObject1.get("name");
            }
		}
		else
		if (o.has("multiEnumValue")) {
			JSONArray jsonArray = ((JSONObject)o.get("multiEnumValue")).getJSONArray("enumValue");
			JSONArray jsonArray1 = new JSONArray();
			for(int i=0;i<jsonArray.length();i++){
	            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
	            if (jsonObject1.has("localizedLabel")) {
	            	jsonArray1.put(jsonObject1.optString("localizedLabel"));
	            }
	            else {
	            	jsonArray1.put(jsonObject1.optString("name"));
	            }
	        }
			return jsonArray1;
		}
		else			
		if (o.has("value")) {
			return o.get("value");
		}			
		return null;
	}
	
	private boolean processGroup(String groupName, int idx, JSONArray row, JSONArray metas, JSONObject currentObject) throws JCException {
		
		int idIndex = ((JSONObject)metas.get(idx)).getInt("groupIdIdx");
		Object key = getValue((JSONObject)row.get(idIndex));
		
		// group id is null, do nothing
		if (key==null) {
			return false;
		}
		
		//make sure parent exist and get it
		String parentsString = ((JSONObject)metas.get(idx)).getString("parent");
		
		// from top level parent look to immediate parent for this group
		JSONObject parent = currentObject;	

		// if parent is "", then first level child
		if (parentsString.length()>0) {
			// find parent with pattern JSONObject->JSONArray->JSONObject->JSONArray...
			String[] parents =parentsString.split(",");
			
			for (int i=0; i<parents.length; i++) {
				String parentName = parents[i];
				Map<String, Object> groupMetaInfo = findGroupMetaInfo(parentName, metas);

				// get group items for this parent
				JSONArray groupItems = parent.getJSONArray(parentName);
				
				// find/create right row of this parent group
				String groupId = (String)groupMetaInfo.get("groupId");
				Integer groupIdIdx = (Integer)groupMetaInfo.get("groupIdIdx");
				
				JSONObject p = findMatchedGroupItem(groupItems, row, groupId, groupIdIdx);
				parent = p;
			}		 
		}
		
		// add data to parent if needed
		JSONArray groupItems = null;
		if (parent.has(groupName)) {
			groupItems = parent.getJSONArray(groupName);
		}
		else{
			groupItems = new JSONArray();
			parent.put(groupName, groupItems);			
		}
		
		Map<String, Object> groupMetaInfo = findGroupMetaInfo(groupName, metas);
		String groupId = (String)groupMetaInfo.get("groupId");
		Integer groupIdIdx = (Integer)groupMetaInfo.get("groupIdIdx");
		
		// handle cases like ["a", "b", "c"]
		if (groupId.length()==0) {
			Object p = findMatchedGroupItemWithoutName(groupItems, row, groupIdIdx);
			if(p == null) {
				Object o = getValue((JSONObject)row.get(groupIdIdx));
				if (o != null) {
					groupItems.put(o);
				}
				
			}			
		}
		else {
			JSONObject p = findMatchedGroupItem(groupItems, row, groupId, groupIdIdx);
			
			// need create a new one
			if(p == null) {
				JSONObject o = new JSONObject();
				@SuppressWarnings("unchecked")
				List<Integer> columns = (List<Integer>)groupMetaInfo.get("columns");
				// we can have cases of value array without a name
				if (columns.size()==1 && metas.getJSONObject(0).getString("newName").length()==0) {
					groupItems.put(((JSONObject)row.get(0)).get("value"));
				}
				else {
					for (int i: columns) {
						o.put( metas.getJSONObject(i).getString("newName"),  getValue((JSONObject)row.get(i)));
					}				
					groupItems.put(o);
				}
			}		
		}
		return true;
	}
	
	private JSONObject findMatchedGroupItem(JSONArray groupItems, JSONArray row, String groupId, Integer groupIdIdx){
		JSONObject ret = null;
		for (int i = 0; i < groupItems.length(); i++){
			JSONObject ele = groupItems.getJSONObject(i);			
			// check if this item match
			String itemIdValue = ele.get(groupId).toString();
			//String rowIdValue = ((JSONObject)row.get(groupIdIdx)).get("value").toString();
			String rowIdValue = getValue((JSONObject)row.get(groupIdIdx)).toString();
			if (itemIdValue.equals(rowIdValue)) {				
				ret = ele;
				break;
			}			
		}
		
		return ret;
	}
	
	private Object findMatchedGroupItemWithoutName(JSONArray groupItems, JSONArray row, Integer groupIdIdx){
		Object ret = null;
		for (int i = 0; i < groupItems.length(); i++){
			try {
				Object ele = groupItems.get(i);
			}catch (Exception e) {
				System.out.println("not good");
			}
			Object ele = groupItems.get(i);			
			// check if this item match
			String itemIdValue = ele.toString();
			//String rowIdValue = ((JSONObject)row.get(groupIdIdx)).get("value").toString();
			/*
			try {
				String rowIdValue = getValue((JSONObject)row.get(groupIdIdx)).toString();				
			}catch (Exception e) {			
				System.out.println("no good");
				JSONObject o = (JSONObject)row.get(groupIdIdx);
				String s = o.toString();
				Object s1 = getValue(o);
				String s2 = s1.toString();
				
				
			}
			*/
			Object o = getValue((JSONObject)row.get(groupIdIdx));
			if (o != null && itemIdValue.equals(o.toString())) {
				ret = ele;
				break;
			}			
		}
		
		return ret;
	}
	
	private Map<String, Object> findGroupMetaInfo(String groupName, JSONArray metas){
		Map<String, Object> retMap = new HashMap<>();
		List<Integer> columns = new ArrayList<Integer>();
		boolean firstTime = true;
		for (int i = 0; i < metas.length(); i++){
			JSONObject meta = metas.getJSONObject(i);
			if (meta.has("groupName") && meta.getString("groupName").equals(groupName)) {
				columns.add(i);
				
				if (firstTime) {
					retMap.put("groupId", meta.getString("groupId"));
					retMap.put("groupIdIdx", meta.getInt("groupIdIdx"));
					firstTime = false;					
				}
			}
		}
		retMap.put("columns", columns);
		return retMap;
	}
}
