package com.ibm.openpages.ext.rest.processor;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.ibm.openpages.ext.rest.JCRestHelper;

/**
 * 
 * postprocessor for R2 report
 * @author ali
 *
 */
@Component
public class PostProcessorR2 implements PostProcessor{
    private static Logger logger = Logger.getLogger(PostProcessorR2.class.getName());
	
    public static final String AMR = "amr";
    // 2021-02-01T00:00:00.000-08:00
    public static final DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

    public void process(JSONObject o, JCRestHelper restHelper, String host) {
		logger.info("post processing R2");
		
		o.put("versionNumber", generateDateVersionId());
		
		// amr rating
		if (o.has(AMR)) {
			JSONArray a = o.getJSONArray(AMR);
			
			String amrRating = null;
			Date earliesDate = null;
			for (int i = 0; i < a.length(); i++){
				JSONObject n = a.getJSONObject(i);
				String rating = n.getString("amrRating");
				String amrPubDate = n.getString("amrPubDate");
				try {
					Date dt = df.parse(amrPubDate);
					
					if (amrRating == null || earliesDate.compareTo(dt) > 0) {
						earliesDate = dt;
						amrRating = rating;
					}
					
				} catch (ParseException e) {
					logger.log(Level.SEVERE, "error parsing datetime: "+amrPubDate);				
				}
			}				
			o.remove(AMR);
			o.put("lastAuditRating", amrRating);
		}
		
		//user list
		/*
		JSONArray auditUserList = new JSONArray();
		String userId;
		if (o.has("entityLeadAuditor")) {
			userId = o.getString("entityLeadAuditor");
			auditUserList.put(userId);
		}
		if (o.has("entityAuditOwner")) {
			userId = o.getString("entityAuditOwner");
			auditUserList.put(userId);
		}
		if (o.has("entityAuditController")) {
			userId = o.getString("entityAuditController");
			auditUserList.put(userId);
		}
		if (o.has("entityAdditionalEditors")) {
			userId = o.getString("entityAdditionalEditors");
			auditUserList.put(userId);
		}
		if (o.has("entityAdditionalLeadAuditorss")) {
			userId = o.getString("entityAdditionalLeadAuditorss");
			auditUserList.put(userId);
		}
		
		o.put("bmqsClusterUsers", auditUserList);
		*/
	}
    
	public String generateDateVersionId() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddhhmmss");
		String ret = formatter.format(new Date());
		return ret;
	}
}
